# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['detettore']
install_requires = \
['biopython>=1.79,<2.0',
 'numba>=0.53.1,<0.54.0',
 'numpy>=1.21.0,<2.0.0',
 'pysam>=0.16.0,<0.17.0',
 'scipy>=1.7.0,<2.0.0']

setup_kwargs = {
    'name': 'detettore',
    'version': '2.0',
    'description': 'A tool to detect transposable element polymorphisms',
    'long_description': None,
    'author': 'cstritt',
    'author_email': 'crstp.strt@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/cstritt/detettore',
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<3.10',
}


setup(**setup_kwargs)
